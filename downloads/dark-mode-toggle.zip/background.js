async function toggleDarkModeOnActiveTab(enabled) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id || tab.url?.startsWith("chrome://") || tab.url?.startsWith("chrome-extension://")) {
    return null;
  }

  return chrome.tabs.sendMessage(tab.id, {
    type: enabled === undefined ? "TOGGLE_DARK_MODE" : "SET_DARK_MODE",
    enabled
  });
}

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "toggle-dark-mode") {
    await toggleDarkModeOnActiveTab(undefined);
  }
});
