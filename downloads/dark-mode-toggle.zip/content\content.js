const DARK_MODE_CLASS = "dmt-dark-mode";
const STYLE_ID = "dmt-dark-mode-styles";

const darkModeStyles = `
  html.${DARK_MODE_CLASS} {
    color-scheme: dark !important;
    filter: invert(1) hue-rotate(180deg) !important;
    background-color: #fff !important;
  }

  html.${DARK_MODE_CLASS} img,
  html.${DARK_MODE_CLASS} video,
  html.${DARK_MODE_CLASS} iframe,
  html.${DARK_MODE_CLASS} embed,
  html.${DARK_MODE_CLASS} object,
  html.${DARK_MODE_CLASS} picture,
  html.${DARK_MODE_CLASS} canvas,
  html.${DARK_MODE_CLASS} svg image,
  html.${DARK_MODE_CLASS} [style*="background-image"] {
    filter: invert(1) hue-rotate(180deg) !important;
  }

  html.${DARK_MODE_CLASS} ::-webkit-scrollbar {
    width: 12px;
    height: 12px;
  }

  html.${DARK_MODE_CLASS} ::-webkit-scrollbar-track {
    background: #1a1a1a;
  }

  html.${DARK_MODE_CLASS} ::-webkit-scrollbar-thumb {
    background: #555;
    border-radius: 6px;
  }
`;

function ensureStylesInjected() {
  if (document.getElementById(STYLE_ID)) {
    return;
  }

  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = darkModeStyles;
  (document.head || document.documentElement).appendChild(style);
}

function setDarkMode(enabled) {
  ensureStylesInjected();
  document.documentElement.classList.toggle(DARK_MODE_CLASS, enabled);
}

function isDarkModeEnabled() {
  return document.documentElement.classList.contains(DARK_MODE_CLASS);
}

function getHostname() {
  try {
    return window.location.hostname || "unknown";
  } catch {
    return "unknown";
  }
}

async function loadSavedState() {
  const hostname = getHostname();
  const result = await chrome.storage.local.get(["siteSettings"]);
  const settings = result.siteSettings || {};
  return Boolean(settings[hostname]);
}

async function saveState(enabled) {
  const hostname = getHostname();
  const result = await chrome.storage.local.get(["siteSettings"]);
  const settings = result.siteSettings || {};
  settings[hostname] = enabled;
  await chrome.storage.local.set({ siteSettings: settings });
}

async function init() {
  const enabled = await loadSavedState();
  if (enabled) {
    setDarkMode(true);
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "GET_DARK_MODE_STATE") {
    sendResponse({ enabled: isDarkModeEnabled(), hostname: getHostname() });
    return true;
  }

  if (message.type === "TOGGLE_DARK_MODE") {
    const nextState = message.enabled ?? !isDarkModeEnabled();
    setDarkMode(nextState);
    saveState(nextState).then(() => {
      sendResponse({ enabled: nextState, hostname: getHostname() });
    });
    return true;
  }

  if (message.type === "SET_DARK_MODE") {
    setDarkMode(message.enabled);
    saveState(message.enabled).then(() => {
      sendResponse({ enabled: message.enabled, hostname: getHostname() });
    });
    return true;
  }
});

init();
