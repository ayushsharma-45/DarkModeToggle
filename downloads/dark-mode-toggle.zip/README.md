# Dark Mode Toggle — Chrome Extension

A Chrome extension that adds a button to turn on dark mode for websites that do not provide their own dark theme.

## Features

- Toggle dark mode from the extension popup
- Remembers your choice **per website**
- Keyboard shortcut: `Alt+Shift+D`
- Works on most regular web pages

## How it works

The extension uses a CSS color-inversion technique:

1. Inverts page colors to create a dark appearance
2. Re-inverts images and videos so they still look normal

This works well on many sites, but complex layouts (maps, design tools, video editors) may look imperfect.

## Install (Developer Mode)

1. Open Chrome and go to `chrome://extensions`
2. Enable **Developer mode** (top-right toggle)
3. Click **Load unpacked**
4. Select the `dark-mode-toggle` folder from this project
5. Pin the extension icon to your toolbar for quick access

## Usage

1. Visit any website without dark mode
2. Click the extension icon in the toolbar
3. Press the toggle button to turn dark mode **On** or **Off**
4. Your preference is saved for that domain

## Project structure

```
dark-mode-toggle/
├── manifest.json
├── background.js
├── content/
│   ├── content.js
│   └── dark-mode.css
├── popup/
│   ├── popup.html
│   ├── popup.css
│   └── popup.js
└── icons/
```

## Permissions

- **activeTab** — interact with the current tab
- **storage** — save per-site dark mode preferences
- **scripting** — inject the content script when needed
- **host_permissions** — run on web pages you visit

## Limitations

- Does not work on `chrome://`, `edge://`, or extension pages
- Some sites with heavy JavaScript styling may need a page refresh after toggling
- Already-dark websites may look wrong if you force dark mode on
