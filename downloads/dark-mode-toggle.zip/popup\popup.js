const toggleBtn = document.getElementById("toggle-btn");
const toggleLabel = document.getElementById("toggle-label");
const siteName = document.getElementById("site-name");

function showError(message) {
  let errorEl = document.querySelector(".popup__error");
  if (!errorEl) {
    errorEl = document.createElement("p");
    errorEl.className = "popup__error";
    document.querySelector(".popup").appendChild(errorEl);
  }
  errorEl.textContent = message;
}

function updateUI(enabled, hostname) {
  toggleBtn.setAttribute("aria-pressed", String(enabled));
  toggleLabel.textContent = enabled ? "On" : "Off";
  siteName.textContent = hostname || "This page";
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function sendMessageToTab(tabId, message) {
  try {
    return await chrome.tabs.sendMessage(tabId, message);
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content/content.js"]
    });
    return chrome.tabs.sendMessage(tabId, message);
  }
}

async function initPopup() {
  const tab = await getActiveTab();

  if (!tab?.id) {
    showError("No active tab found.");
    toggleBtn.disabled = true;
    return;
  }

  if (
    tab.url?.startsWith("chrome://") ||
    tab.url?.startsWith("chrome-extension://") ||
    tab.url?.startsWith("edge://")
  ) {
    showError("Dark mode cannot be applied on browser internal pages.");
    toggleBtn.disabled = true;
    siteName.textContent = "Unsupported page";
    return;
  }

  try {
    const response = await sendMessageToTab(tab.id, { type: "GET_DARK_MODE_STATE" });
    updateUI(response.enabled, response.hostname);
  } catch {
    showError("Could not connect to this page. Try refreshing the tab.");
    toggleBtn.disabled = true;
  }
}

toggleBtn.addEventListener("click", async () => {
  const tab = await getActiveTab();
  if (!tab?.id) {
    return;
  }

  const isEnabled = toggleBtn.getAttribute("aria-pressed") === "true";

  try {
    const response = await sendMessageToTab(tab.id, {
      type: "SET_DARK_MODE",
      enabled: !isEnabled
    });
    updateUI(response.enabled, response.hostname);
  } catch {
    showError("Failed to toggle dark mode. Refresh the page and try again.");
  }
});

initPopup();
